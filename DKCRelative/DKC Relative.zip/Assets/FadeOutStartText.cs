﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FadeOutStartText : MonoBehaviour {
/*
	float x = 0;
	TextMesh txt;
	bool fade = false;

	void Start(){
		txt = GetComponent<TextMesh>();
	}

	void Update () {
		if(Input.GetButtonDown("Submit"))
			fade = true;
		if(fade){
			x += Time.deltaTime;
			txt.color = Color.white*Mathf.Min(1-x , 1);
			if(x > 1)
				Destroy(gameObject);
		}
	}*/

	void Update () {
		if(Input.GetButtonDown("Submit"))
			Destroy(gameObject);
	}
}
