﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadNextStage : MonoBehaviour {


	private void OnTriggerEnter2D(){
		SceneManager.LoadScene(1 , LoadSceneMode.Single);
		//SceneManager.SetActiveScene(SceneManager.GetSceneByName("MudholeMarsh"));
	}


	public float realPos;

	void Start(){
		realPos = transform.position.x;
	}
	
	void Update(){
		if(Menu.showLightWarp)
			transform.position = new Vector3(realPos + Player.velx/Player.C*Mathf.Abs(realPos-Player.posx) , transform.position.y , transform.position.z);
		else
			transform.position = new Vector3(realPos , transform.position.y  , transform.position.z);
	}
}
